function setup() {
  createCanvas(400, 400);
}
let spaceship;

function preload() {
  spaceship = loadImage("SpaceShip.png");
}
function draw() {
  background(20);
  tint(mouseX, mouseY, mouseX /2 + mouseY /2);
  image(spaceship, 100, 100, 200, 200);
}
